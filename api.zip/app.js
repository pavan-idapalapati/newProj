import express from "express";
import bodyParser from "body-parser";

import { sendRawMail } from "./handlers/emails.js";
// Set up the express app
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());

// get all todos
app.get("/api/v1/todos", (req, res) => {
  res.status(200).send({
    success: "true",
    message: "todos retrieved successfully",
    todos: [],
  });
});
const PORT = 5000;

app.post("/api/v1/sendRawMail", async (req, res) => {
  const { email, subject, body } = req.body;
  await sendRawMail({ email, subject, body });

  res.status(200).send({
    success: "true",
  });
});

app.listen(PORT, () => {
  console.log(`server running on port ${PORT}`);
});
